package dao;

import java.util.List;

import model.Soda;

/**
 *
 * @author MO354826
 */
public interface SodaDao {
    public Soda getSodaById(int id);
    public List<Soda> getSodas();
}
