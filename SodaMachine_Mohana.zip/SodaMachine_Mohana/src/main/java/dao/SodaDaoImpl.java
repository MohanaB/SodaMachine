package dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import model.Soda;

/**
 *
 * @author MO354826
 */
public class SodaDaoImpl implements SodaDao {
    HashMap<Integer,Soda> sodas;
    
    public SodaDaoImpl() {
        sodas = new HashMap<>();
        sodas.put(1, new Soda(1,"Lemonade",new BigDecimal("1.85"),3));
        sodas.put(2, new Soda(2,"Fanta",new BigDecimal("1.50"),9));
        sodas.put(3, new Soda(3,"Mazza",new BigDecimal("2.10"),2));
        sodas.put(4, new Soda(4,"7Up",new BigDecimal("1.85"),5));
             
    }

    @Override
    public Soda getSodaById(int id) {
        return sodas.get(id);
    }

    @Override
    public List<Soda> getSodas() {
        return new ArrayList<>(sodas.values());
    }
    
}
