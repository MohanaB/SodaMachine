package service;

import java.math.BigDecimal;

import java.util.List;
import javax.inject.Inject;

import org.springframework.stereotype.Service;

import dao.SodaDao;
import model.Soda;
import service.ConvertMoney;

/**
 *
 * @author MO354826
 */
@Service
public class SodaServiceImpl implements SodaService {
    private SodaDao sodaDao;
    private BigDecimal balance;
    private int selection;
    private ConvertMoney myChange;
    private String message;
  
    @Inject
    public SodaServiceImpl(SodaDao sodaDao) {
        this.sodaDao = sodaDao;
        balance = new BigDecimal("0.00");
        selection = 0;
        myChange = null;
        message = null;
    }

    @Override
    public void addMoney(String amount) {
        switch (amount) {
           case "quarter":
                balance = balance.add(new BigDecimal("0.25"));
                break;
                       default:
        }
    }
    @Override
    public void purchase() {
        if (selection != 0) {

            Soda soda = sodaDao.getSodaById(selection);
            BigDecimal selectionPrice = soda.getPrice();
            if (soda.getQuantity() <= 0) {
                message = "SORRY OUT OF STOCK!!!";
            } else if (balance.compareTo(selectionPrice) < 0) {
                BigDecimal difference = selectionPrice.subtract(balance);
                message = "Insufficient amount add: " + difference;
            } else {
                BigDecimal newBalance = balance.subtract(selectionPrice);
                ConvertMoney change = new ConvertMoney(newBalance);
                myChange = change;
                balance = new BigDecimal("0.00");
                int newSodaQuantity = soda.getQuantity() - 1;
                soda.setQuantity(newSodaQuantity);
                message = "Enjoy your Drink!!Thank You!!!";
            }
        }
    }
    @Override
    public void returnChange() {
    	ConvertMoney change = new ConvertMoney(balance);
       myChange = change;
        balance = new BigDecimal("0.00");
        selection = 0;
        message = null;
    }
    
    @Override
    public List<Soda> getSodasList() {
        return sodaDao.getSodas();
    }
    @Override
    public Soda getSodaById(int id) {
        return sodaDao.getSodaById(id);
    }

    @Override
    public BigDecimal getBalance() {
        return balance;
    }
    @Override
    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }
    @Override
    public int getSelection() {
        return selection;
    }
    @Override
    public void setSelection(int Selection) {
        this.selection = Selection;
    }
    @Override
    public ConvertMoney getMyChange() {
        return myChange;
    }
    @Override
    public void setMyChange(ConvertMoney myChange) {
        this.myChange = myChange;
    }      
    @Override
    public String getMessage() {
        return message;
    }
    @Override
    public void setMessage(String message) {
        this.message = message;
    }    
    
  

}
