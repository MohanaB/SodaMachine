package service;

import java.math.BigDecimal;
import java.util.List;
import model.Soda;

/**
 *
 * @author MO354826
 */
public interface SodaService {
    
    public void addMoney(String amount);
    
    public void purchase();
    
    public void returnChange();

    BigDecimal getBalance();

    String getMessage();

    ConvertMoney getMyChange();

    int getSelection();

    Soda getSodaById(int id);

    List<Soda> getSodasList();

    void setBalance(BigDecimal balance);

    void setMessage(String message);

    void setMyChange(ConvertMoney myChange);

    void setSelection(int Selection);
    
}
