package service;

import java.math.BigDecimal;


/**
 *
 * @author MO354826
 */
public class ConvertMoney {
    private int quarters;
   private int money;
    
    public ConvertMoney(BigDecimal balance) {
    	money = Integer.parseInt(balance.toString().replace(".", ""));
        quarters = money / 25;
       
    }

    public int getQuarters() {
        return quarters;
    }


    
}
