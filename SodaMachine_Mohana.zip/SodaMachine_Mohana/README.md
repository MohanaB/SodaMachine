# vending-machine-spring-mvc
Java web application that simulates a vending machine. Uses Java, JSP, and Spring Core / MVC.
